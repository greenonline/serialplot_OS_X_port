#define QT_FEATURE_cups 1
#define QT_FEATURE_cupsjobwidget 1
