#define QT_FEATURE_ntddmodm -1
